FOOTBALL WORLD CUP PREDICTION & DATA MINING SYSTEM

Run:
1. Open terminal in this folder.
2. Install packages:
   pip install -r requirements.txt
3. Start website:
   streamlit run app.py

The project contains exactly 10,000 generated World Cup style match records
(32 national teams, Elo ratings, FIFA rank, recent form, squad value, goals, result)
and implements:
- Dataset creation/viewing
- Data preprocessing (median / mode filling, duplicate removal)
- Decision Tree classification (J48 equivalent): will Team A win?
- Naive Bayes classification: will Team A win?
- Linear regression: goals scored by Team A
- Association rule mining (Apriori)
- K-Means clustering of matches
- Comparison module (compares every technique side by side and recommends the best fit for match prediction)
- Match Predictor: pick any two teams, get win probabilities, expected goals and likely scorelines
- Tournament Simulator: Monte-Carlo World Cup (groups + knockouts) with each team's chance of winning

The data is synthetic (generated with a fixed random seed, so results are repeatable); it is not real match history.
Weka is not required.
