import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from math import factorial
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.linear_model import LinearRegression
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, mean_absolute_error, r2_score, confusion_matrix
from mlxtend.frequent_patterns import apriori, association_rules
import time
from sklearn.model_selection import StratifiedKFold, KFold, cross_val_score
from sklearn.metrics import (precision_score, recall_score, f1_score, roc_auc_score,
                             roc_curve, mean_squared_error, silhouette_score,
                             davies_bouldin_score)

st.set_page_config(page_title="World Cup Prediction", page_icon="⚽", layout="wide")

# ----------------------------------------------------------------------------
# Teams used to generate the synthetic dataset: name -> (confederation, base Elo)
# ----------------------------------------------------------------------------
TEAMS = {
    "Argentina":("South America",2140),"France":("Europe",2130),"Spain":("Europe",2110),
    "England":("Europe",2090),"Brazil":("South America",2080),"Portugal":("Europe",2050),
    "Netherlands":("Europe",2040),"Germany":("Europe",2030),"Belgium":("Europe",1990),
    "Italy":("Europe",1990),"Croatia":("Europe",1960),"Uruguay":("South America",1960),
    "Colombia":("South America",1940),"Morocco":("Africa",1920),"Japan":("Asia",1900),
    "USA":("North America",1890),"Mexico":("North America",1880),"Senegal":("Africa",1880),
    "Switzerland":("Europe",1880),"Denmark":("Europe",1880),"South Korea":("Asia",1850),
    "Poland":("Europe",1840),"Serbia":("Europe",1830),"Iran":("Asia",1820),
    "Ecuador":("South America",1810),"Australia":("Asia",1800),"Nigeria":("Africa",1790),
    "Egypt":("Africa",1780),"Canada":("North America",1770),"Cameroon":("Africa",1740),
    "Ghana":("Africa",1730),"Saudi Arabia":("Asia",1700)}

CLS_FEATURES=["Elo_A","Elo_B","FIFA_Rank_A","FIFA_Rank_B","Form_A","Form_B",
              "Squad_Value_A_M","Squad_Value_B_M","Home_Adv"]
CLS_LABELS=["Elo (Team A)","Elo (Team B)","FIFA Rank (A)","FIFA Rank (B)","Form pts (A)","Form pts (B)",
            "Squad Value € M (A)","Squad Value € M (B)","Home Advantage (-1/0/1)"]
CLS_DEFAULTS=[2000,1850,6,25,10,7,600,150,0]

def show_df(frame,**kw):
    """st.dataframe that works on old and new Streamlit versions."""
    try:
        st.dataframe(frame,width="stretch",**kw)
    except TypeError:
        st.dataframe(frame,use_container_width=True,**kw)

@st.cache_data
def create_dataset(n=10000):
    rng=np.random.default_rng(42)
    names=list(TEAMS)
    base=np.array([TEAMS[t][1] for t in names],dtype=float)
    conf=np.array([TEAMS[t][0] for t in names])

    ia=rng.integers(0,len(names),n)
    ib=rng.integers(0,len(names),n)
    same=ia==ib
    ib[same]=(ib[same]+rng.integers(1,len(names),same.sum()))%len(names)   # a team never plays itself

    year=rng.choice([1998,2002,2006,2010,2014,2018,2022],n)
    stage=rng.choice(["Group Stage","Round of 16","Quarter-final","Semi-final","Third Place","Final"],
                     n,p=[.74,.12,.07,.04,.015,.015])
    venue=rng.choice(["Neutral","Team A Host","Team B Host"],n,p=[.90,.05,.05])
    home=np.where(venue=="Team A Host",1,np.where(venue=="Team B Host",-1,0))

    elo_a=np.round(base[ia]+rng.normal(0,35,n))
    elo_b=np.round(base[ib]+rng.normal(0,35,n))
    rank_a=np.clip(np.round(1+(2150-elo_a)/9+rng.normal(0,3,n)),1,80)
    rank_b=np.clip(np.round(1+(2150-elo_b)/9+rng.normal(0,3,n)),1,80)
    form_a=np.clip(np.round(7+(elo_a-1900)/60+rng.normal(0,2.2,n)),0,15)
    form_b=np.clip(np.round(7+(elo_b-1900)/60+rng.normal(0,2.2,n)),0,15)
    sq_a=np.round(25*np.exp((elo_a-1700)/130)*rng.lognormal(0,.25,n),1)
    sq_b=np.round(25*np.exp((elo_b-1700)/130)*rng.lognormal(0,.25,n),1)

    diff=(elo_a-elo_b)+60*home
    log_gap=diff/600+(form_a-form_b)*0.02
    lam_a=1.30*np.exp(log_gap); lam_b=1.30*np.exp(-log_gap)
    goals_a=rng.poisson(lam_a); goals_b=rng.poisson(lam_b)

    poss=np.clip(np.round(50+diff/18+rng.normal(0,6,n),1),25,75)
    shots_a=rng.poisson(11*np.exp(diff/900)); shots_b=rng.poisson(11*np.exp(-diff/900))

    result=np.where(goals_a>goals_b,"Win",np.where(goals_a<goals_b,"Loss","Draw"))
    total=goals_a+goals_b
    favourite=np.where(elo_a-elo_b>50,"Team A Favourite",np.where(elo_a-elo_b<-50,"Team B Favourite","Evenly Matched"))
    band=np.where(total<=1,"Low Scoring",np.where(total<=3,"Medium Scoring","High Scoring"))

    df=pd.DataFrame({
        "Match_ID":[f"M{i:05d}" for i in range(1,n+1)],
        "Year":year,"Stage":stage,"Team_A":np.array(names)[ia],"Team_B":np.array(names)[ib],
        "Confederation_A":conf[ia],"Confederation_B":conf[ib],"Venue":venue,"Home_Adv":home,
        "Elo_A":elo_a,"Elo_B":elo_b,"FIFA_Rank_A":rank_a,"FIFA_Rank_B":rank_b,
        "Form_A":form_a,"Form_B":form_b,"Squad_Value_A_M":sq_a,"Squad_Value_B_M":sq_b,
        "Possession_A":poss,"Shots_A":shots_a,"Shots_B":shots_b,
        "Goals_A":goals_a,"Goals_B":goals_b,"Total_Goals":total,
        "Favourite":favourite,"Goals_Band":band,"Result":result,
        "A_Win":np.where(result=="Win","Win","Not Win")})
    for col in ["FIFA_Rank_A","Form_B","Squad_Value_A_M"]:      # deliberately inject missing values
        idx=rng.choice(n,20,replace=False)
        df.loc[idx,col]=np.nan
    return df

def preprocess(df):
    data=df.copy()
    for col in data.select_dtypes(include=np.number).columns:
        data[col]=data[col].fillna(data[col].median())
    for col in data.select_dtypes(exclude=np.number).columns:
        data[col]=data[col].fillna(data[col].mode()[0])
    return data.drop_duplicates()

def mine_rules(freq,n_rows):
    """Works with both old and new mlxtend versions of association_rules."""
    try:
        return association_rules(freq,metric="confidence",min_threshold=.55)
    except TypeError:
        return association_rules(freq,num_itemsets=n_rows,metric="confidence",min_threshold=.55)

RULE_COLS=["Confederation_A","Confederation_B","Stage","Favourite","Goals_Band","Result"]

def encode_for_rules(data):
    return pd.get_dummies(data[RULE_COLS].astype(str)).astype(bool)

@st.cache_data
def compute_comparison(data):
    """Runs every module's model with the SAME settings used in its own module."""
    res={}
    X=data[CLS_FEATURES]; y=(data.A_Win=="Win").astype(int)
    Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=.2,random_state=42,stratify=y)
    cv=StratifiedKFold(n_splits=5,shuffle=True,random_state=42)
    models={"Decision Tree":DecisionTreeClassifier(max_depth=6,random_state=42),
            "Naive Bayes":GaussianNB()}
    clf={}; cms={}; roc={}
    for name,m in models.items():
        t0=time.perf_counter(); m.fit(Xtr,ytr); fit_ms=(time.perf_counter()-t0)*1000
        pred=m.predict(Xte); proba=m.predict_proba(Xte)[:,1]
        cvs=cross_val_score(m,X,y,cv=cv,scoring="accuracy")
        fpr,tpr,_=roc_curve(yte,proba)
        clf[name]={"Accuracy":accuracy_score(yte,pred),
                   "Precision":precision_score(yte,pred,zero_division=0),
                   "Recall":recall_score(yte,pred,zero_division=0),
                   "F1-Score":f1_score(yte,pred,zero_division=0),
                   "ROC-AUC":roc_auc_score(yte,proba),
                   "CV Accuracy (5-fold)":cvs.mean(),
                   "CV Std Dev":cvs.std(),
                   "Training Time (ms)":fit_ms}
        cms[name]=confusion_matrix(yte,pred)
        roc[name]=(fpr,tpr)
    res["clf"]=clf; res["cms"]=cms; res["roc"]=roc
    res["baseline"]=max(float(yte.mean()),1-float(yte.mean()))
    res["n_test"]=int(len(yte))

    Xr=data[CLS_FEATURES]; yr=data.Goals_A
    Xtr,Xte,ytr,yte=train_test_split(Xr,yr,test_size=.2,random_state=42)
    lr=LinearRegression().fit(Xtr,ytr); p=lr.predict(Xte)
    cv_r2=cross_val_score(LinearRegression(),Xr,yr,
                          cv=KFold(n_splits=5,shuffle=True,random_state=42),scoring="r2").mean()
    res["reg"]={"R2":r2_score(yte,p),"MAE":mean_absolute_error(yte,p),
                "RMSE":float(np.sqrt(mean_squared_error(yte,p))),
                "CV_R2":cv_r2,"mean_goals":float(yr.mean())}

    encoded=encode_for_rules(data)
    freq=apriori(encoded,min_support=.08,use_colnames=True)
    ar={"itemsets":int(len(freq)),"rules":0,"max_lift":None,"avg_conf":None,"avg_lift":None,"top_rule":"-"}
    if len(freq):
        rules=mine_rules(freq,len(encoded))
        if len(rules):
            rules=rules.sort_values("lift",ascending=False)
            top=rules.iloc[0]
            ar.update({"rules":int(len(rules)),"max_lift":float(rules["lift"].max()),
                       "avg_conf":float(rules["confidence"].mean()),
                       "avg_lift":float(rules["lift"].mean()),
                       "top_rule":", ".join(sorted(top["antecedents"]))+"  →  "+", ".join(sorted(top["consequents"]))})
    res["ar"]=ar

    cl_features=["Elo_A","Elo_B","Form_A","Form_B","Total_Goals"]
    Xc=StandardScaler().fit_transform(data[cl_features])
    km=KMeans(n_clusters=3,random_state=42,n_init=10)
    labels=km.fit_predict(Xc)
    win_flag=(data.A_Win=="Win").astype(int).values
    rate=pd.Series(win_flag).groupby(labels).mean()
    size=pd.Series(labels).value_counts().sort_index()
    res["km"]={"k":3,
               "silhouette":float(silhouette_score(Xc,labels,sample_size=3000,random_state=42)),
               "davies_bouldin":float(davies_bouldin_score(Xc,labels)),
               "inertia":float(km.inertia_),
               "win_rate":[float(v) for v in rate.values],
               "sizes":[int(v) for v in size.values]}
    return res

def pick_winner(vals,higher=True,digits=4):
    """vals: {model_name: number}. Returns winning model name or 'Tie'."""
    names=list(vals); a=round(vals[names[0]],digits); b=round(vals[names[1]],digits)
    if a==b: return "Tie"
    return names[0] if (a>b)==higher else names[1]

# ----------------------------------------------------------------------------
# Helpers for Match Predictor and Tournament Simulator
# ----------------------------------------------------------------------------
@st.cache_data
def team_profiles(data):
    cols=["Team","Elo","FIFA_Rank","Form","Squad_Value_M"]
    a=data[["Team_A","Elo_A","FIFA_Rank_A","Form_A","Squad_Value_A_M"]].set_axis(cols,axis=1)
    b=data[["Team_B","Elo_B","FIFA_Rank_B","Form_B","Squad_Value_B_M"]].set_axis(cols,axis=1)
    return pd.concat([a,b]).groupby("Team").mean().sort_values("Elo",ascending=False)

@st.cache_resource
def train_final_models(data):
    X=data[CLS_FEATURES]; y=(data.A_Win=="Win").astype(int)
    dt=DecisionTreeClassifier(max_depth=6,random_state=42).fit(X,y)
    nb=GaussianNB().fit(X,y)
    lr=LinearRegression().fit(X,data.Goals_A)
    return dt,nb,lr

def pair_features(prof,a,b,home=0):
    pa,pb=prof.loc[a],prof.loc[b]
    return [pa.Elo,pb.Elo,pa.FIFA_Rank,pb.FIFA_Rank,pa.Form,pb.Form,pa.Squad_Value_M,pb.Squad_Value_M,home]

def expected_goals(lr,prof,a,b,home=0):
    xa=pd.DataFrame([pair_features(prof,a,b,home)],columns=CLS_FEATURES)
    xb=pd.DataFrame([pair_features(prof,b,a,-home)],columns=CLS_FEATURES)
    return float(np.clip(lr.predict(xa)[0],.2,4.5)),float(np.clip(lr.predict(xb)[0],.2,4.5))

def poisson_grid(la,lb,k=10):
    pa=np.array([np.exp(-la)*la**i/factorial(i) for i in range(k+1)])
    pb=np.array([np.exp(-lb)*lb**i/factorial(i) for i in range(k+1)])
    return np.outer(pa,pb)

@st.cache_data
def simulate_tournament(data,n_sims,seed):
    """Monte-Carlo World Cup: 32 teams, 8 groups of 4, then knockout rounds.
    Goal rates come from the Linear Regression module; groups are drawn at random in every simulation."""
    prof=team_profiles(data); teams=list(prof.index); T=len(teams)
    _,_,lr=train_final_models(data)
    rows=[pair_features(prof,teams[i],teams[j]) for i in range(T) for j in range(T)]
    lam=np.clip(lr.predict(pd.DataFrame(rows,columns=CLS_FEATURES)),.2,4.5).reshape(T,T)
    rng=np.random.default_rng(seed)
    cnt={k:np.zeros(T) for k in ["Round of 16","Quarter-final","Semi-final","Final","Champion"]}

    def ko(a,b):
        x=rng.poisson(lam[a,b]); y=rng.poisson(lam[b,a])
        if x>y: return a
        if y>x: return b
        return a if rng.random()<lam[a,b]/(lam[a,b]+lam[b,a]) else b      # extra time / penalties

    for _ in range(n_sims):
        groups=rng.permutation(T).reshape(8,4)
        win=[];run=[]
        for g in groups:
            pts=np.zeros(4);gf=np.zeros(4);ga=np.zeros(4)
            for i in range(4):
                for j in range(i+1,4):
                    x=rng.poisson(lam[g[i],g[j]]); y=rng.poisson(lam[g[j],g[i]])
                    gf[i]+=x;ga[i]+=y;gf[j]+=y;ga[j]+=x
                    if x>y: pts[i]+=3
                    elif y>x: pts[j]+=3
                    else: pts[i]+=1;pts[j]+=1
            order=np.argsort(-(pts*1e4+(gf-ga)*100+gf+rng.random(4)*.5))
            win.append(g[order[0]]);run.append(g[order[1]])
        rnd=[(win[0],run[1]),(win[2],run[3]),(win[4],run[5]),(win[6],run[7]),
             (win[1],run[0]),(win[3],run[2]),(win[5],run[4]),(win[7],run[6])]
        for stage in ["Round of 16","Quarter-final","Semi-final","Final"]:
            for a,b in rnd: cnt[stage][a]+=1;cnt[stage][b]+=1
            nxt=[ko(a,b) for a,b in rnd]
            rnd=[(nxt[i],nxt[i+1]) for i in range(0,len(nxt),2)] if len(nxt)>1 else nxt
        cnt["Champion"][rnd[0]]+=1
    out=pd.DataFrame({k:v/n_sims*100 for k,v in cnt.items()},index=teams)
    out.index.name="Team"
    return out.sort_values("Champion",ascending=False)

df=create_dataset(10000)

st.title("⚽ Football World Cup Prediction & Data Mining System")
st.caption("Python-only Data Mining & Machine Learning project (synthetic dataset of 10,000 World Cup style matches)")

menu=st.sidebar.radio("Select Module",
    ["Dashboard","Dataset","Preprocessing","Classification",
     "Naive Bayes","Regression","Association Rules","Clustering","Comparison",
     "Match Predictor","Tournament Simulator"])

if menu=="Dashboard":
    st.subheader("Project Overview")
    c1,c2,c3,c4=st.columns(4)
    c1.metric("Total Matches",len(df))
    c2.metric("Team A Wins",int((df.Result=="Win").sum()))
    c3.metric("Draws",int((df.Result=="Draw").sum()))
    c4.metric("Avg Goals / Match",f"{df.Total_Goals.mean():.2f}")
    st.write("The system combines dataset creation, preprocessing, classification, Naive Bayes, regression, association rules, "
             "clustering, a head-to-head match predictor and a full World Cup tournament simulator.")
    g1,g2=st.columns(2)
    with g1:
        fig,ax=plt.subplots()
        df.Result.value_counts().plot(kind="bar",ax=ax,color=["#2e7d32","#f9a825","#c62828"])
        ax.set_xlabel("Result for Team A"); ax.set_ylabel("Number of Matches"); ax.tick_params(axis="x",rotation=0)
        st.pyplot(fig)
    with g2:
        fig,ax=plt.subplots()
        df.Total_Goals.value_counts().sort_index().plot(kind="bar",ax=ax,color="#1565c0")
        ax.set_xlabel("Total Goals in Match"); ax.set_ylabel("Number of Matches"); ax.tick_params(axis="x",rotation=0)
        st.pyplot(fig)

elif menu=="Dataset":
    st.subheader("10,000-Row World Cup Match Dataset")
    st.write("Dataset size:",df.shape)
    st.caption("Synthetic data: team strengths are modelled on realistic Elo ratings, and goals are drawn from a Poisson model. It is not real match history.")
    show_df(df.head(100))
    st.subheader("Dataset Statistics")
    st.dataframe(df.describe(include="all").T)
    st.download_button("Download CSV",df.to_csv(index=False).encode(),
                       "world_cup_matches_10000.csv","text/csv")

elif menu=="Preprocessing":
    st.subheader("Data Preprocessing")
    st.write("Missing values before preprocessing")
    st.dataframe(df.isnull().sum().to_frame("Missing Values"))
    clean=preprocess(df)
    st.write("Missing values after preprocessing")
    st.dataframe(clean.isnull().sum().to_frame("Missing Values"))
    st.write("Original shape:",df.shape)
    st.write("Processed shape:",clean.shape)
    st.success("Missing numerical values were filled with median, categorical values with mode, and duplicate rows were removed.")

elif menu=="Classification":
    st.subheader("Decision Tree Classification (J48 Equivalent): Will Team A Win?")
    data=preprocess(df)
    X=data[CLS_FEATURES]; y=(data.A_Win=="Win").astype(int)
    Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=.2,random_state=42,stratify=y)
    model=DecisionTreeClassifier(max_depth=6,random_state=42)
    model.fit(Xtr,ytr); pred=model.predict(Xte)
    st.metric("Accuracy",f"{accuracy_score(yte,pred)*100:.2f}%")
    st.dataframe(pd.DataFrame(confusion_matrix(yte,pred),
        index=["Actual Not Win","Actual Win"],
        columns=["Predicted Not Win","Predicted Win"]))
    st.info("DecisionTreeClassifier is used as the Python equivalent of the J48 decision-tree practical. "
            "'Not Win' means Team A drew or lost.")
    st.subheader("Try a Prediction")
    vals=[]
    for r in range(0,len(CLS_FEATURES),3):
        cols=st.columns(3)
        for c,i in zip(cols,range(r,min(r+3,len(CLS_FEATURES)))):
            vals.append(c.number_input(CLS_LABELS[i],value=float(CLS_DEFAULTS[i]),key=f"dt_{i}"))
    result=model.predict(pd.DataFrame([vals],columns=CLS_FEATURES))[0]
    st.success("Prediction: Team A "+("WINS" if result else "does NOT win (draw or loss)"))

elif menu=="Naive Bayes":
    st.subheader("Naive Bayes Classification: Will Team A Win?")
    data=preprocess(df)
    X=data[CLS_FEATURES]; y=(data.A_Win=="Win").astype(int)
    Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=.2,random_state=42,stratify=y)
    model=GaussianNB(); model.fit(Xtr,ytr); pred=model.predict(Xte)
    st.metric("Accuracy",f"{accuracy_score(yte,pred)*100:.2f}%")
    st.dataframe(pd.DataFrame(confusion_matrix(yte,pred),
        index=["Actual Not Win","Actual Win"],
        columns=["Predicted Not Win","Predicted Win"]))
    st.subheader("Try a Prediction")
    vals=[]
    for r in range(0,len(CLS_FEATURES),3):
        cols=st.columns(3)
        for c,i in zip(cols,range(r,min(r+3,len(CLS_FEATURES)))):
            vals.append(c.number_input(CLS_LABELS[i],value=float(CLS_DEFAULTS[i]),key=f"nb_{i}"))
    proba=model.predict_proba(pd.DataFrame([vals],columns=CLS_FEATURES))[0,1]
    st.success(f"Probability that Team A wins: {proba*100:.1f}%")

elif menu=="Regression":
    st.subheader("Goals Prediction using Linear Regression (goals scored by Team A)")
    data=preprocess(df)
    X=data[CLS_FEATURES]; y=data.Goals_A
    Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=.2,random_state=42)
    model=LinearRegression(); model.fit(Xtr,ytr); pred=model.predict(Xte)
    c1,c2=st.columns(2)
    c1.metric("R² Score",f"{r2_score(yte,pred):.3f}")
    c2.metric("Mean Absolute Error",f"{mean_absolute_error(yte,pred):.2f} goals")
    fig,ax=plt.subplots()
    ax.scatter(yte+np.random.default_rng(0).normal(0,.08,len(yte)),pred,alpha=.3)
    ax.set_xlabel("Actual Goals (small jitter added)"); ax.set_ylabel("Predicted Goals")
    st.pyplot(fig)
    st.caption("Goals are whole numbers and are very random in football, so a low R² is expected: "
               "team strength moves the average, but cannot fix the exact score.")
    st.subheader("Predict Goals for Team A")
    vals=[]
    for r in range(0,len(CLS_FEATURES),3):
        cols=st.columns(3)
        for c,i in zip(cols,range(r,min(r+3,len(CLS_FEATURES)))):
            vals.append(c.number_input(CLS_LABELS[i],value=float(CLS_DEFAULTS[i]),key=f"rg_{i}"))
    p=model.predict(pd.DataFrame([vals],columns=CLS_FEATURES))[0]
    st.success(f"Expected goals for Team A: {max(0,p):.2f}")

elif menu=="Association Rules":
    st.subheader("Association Rule Mining")
    st.caption("Attributes used: "+", ".join(RULE_COLS))
    encoded=encode_for_rules(preprocess(df))
    freq=apriori(encoded,min_support=.08,use_colnames=True)
    if len(freq):
        rules=mine_rules(freq,len(encoded))
        if len(rules):
            rules=rules[["antecedents","consequents","support","confidence","lift"]].copy()
            rules["antecedents"]=rules.antecedents.apply(lambda x:", ".join(sorted(x)))
            rules["consequents"]=rules.consequents.apply(lambda x:", ".join(sorted(x)))
            show_df(rules.sort_values("lift",ascending=False).head(30))
        else: st.warning("No rules found with these thresholds.")
    else: st.warning("No frequent itemsets found.")

elif menu=="Clustering":
    st.subheader("Match Clustering using K-Means")
    data=preprocess(df)
    features=["Elo_A","Elo_B","Form_A","Form_B","Total_Goals"]
    X=StandardScaler().fit_transform(data[features])
    k=st.slider("Number of Clusters",2,6,3)
    model=KMeans(n_clusters=k,random_state=42,n_init=10)
    data["Cluster"]=model.fit_predict(X)
    show_df(data.groupby("Cluster")[features].mean().round(2))
    fig,ax=plt.subplots()
    ax.scatter(data.Elo_A,data.Elo_B,c=data.Cluster,alpha=.5)
    ax.set_xlabel("Team A Elo"); ax.set_ylabel("Team B Elo")
    st.pyplot(fig)

elif menu=="Comparison":
    st.subheader("Comparison Module: Which Technique Suits the World Cup Prediction System?")
    st.write("Every technique used in this project is run again here with the **same settings, features and train/test split** "
             "as its own module, so the numbers match what you saw earlier. Because the techniques solve different kinds of "
             "problems, the comparison is done in layers: an overview of all five, a fair head-to-head of the two models "
             "that can predict *Win / Not Win*, and then the supporting modules.")
    with st.spinner("Running all models..."):
        R=compute_comparison(preprocess(df))
    clf=R["clf"]; reg=R["reg"]; ar=R["ar"]; km=R["km"]; base=R["baseline"]
    names=list(clf.keys())
    dt,nb=names[0],names[1]

    st.markdown("### 1. Overview of all modules, side by side")
    overview=pd.DataFrame({
        "Module":["Classification","Naive Bayes","Regression","Association Rules","Clustering"],
        "Technique":["Decision Tree (depth 6)","Gaussian Naive Bayes","Linear Regression","Apriori rules","K-Means (k=3)"],
        "Learning Type":["Supervised","Supervised","Supervised","Unsupervised","Unsupervised"],
        "What It Predicts / Finds":["Win or Not Win","Win or Not Win","Goals scored by Team A",
                                    "Which match attributes occur together","Groups of similar matches"],
        "Key Result":[f"Accuracy {clf[dt]['Accuracy']*100:.2f}%",
                      f"Accuracy {clf[nb]['Accuracy']*100:.2f}%",
                      f"R² {reg['R2']:.3f}, MAE {reg['MAE']:.2f} goals",
                      f"{ar['rules']} rules, max lift {ar['max_lift']:.2f}" if ar["rules"] else "No rules found",
                      f"Silhouette {km['silhouette']:.3f}"],
        "Predicts Match Outcome?":["Yes","Yes","Indirectly (expected goals)","No (descriptive)","No (segmentation)"]})
    show_df(overview,hide_index=True)

    st.markdown("### 2. Head-to-head: Decision Tree vs Naive Bayes (Win / Not Win)")
    st.caption(f"Test set: {R['n_test']:,} matches (20%). Always guessing the most common class would score {base*100:.2f}%, "
               "so that is the minimum a useful model must beat.")
    metric_rows=[("Accuracy",True),("Precision",True),("Recall",True),("F1-Score",True),
                 ("ROC-AUC",True),("CV Accuracy (5-fold)",True),("CV Std Dev",False),("Training Time (ms)",False)]
    n_scored=len(metric_rows)-1
    table=[]; wins={n:0 for n in names}
    for m,higher in metric_rows:
        vals={n:clf[n][m] for n in names}
        w=pick_winner(vals,higher,digits=1 if "Time" in m else 4)
        if w in wins and m!="Training Time (ms)": wins[w]+=1
        fmt=(lambda v:f"{v:.1f}") if "Time" in m else (lambda v:f"{v:.4f}")
        table.append({"Metric":m+("" if higher else " (lower is better)"),
                      dt:fmt(vals[dt]),nb:fmt(vals[nb]),"Better":w})
    show_df(pd.DataFrame(table),hide_index=True)

    c1,c2=st.columns(2)
    with c1:
        st.write("**Metric comparison**")
        keys=["Accuracy","Precision","Recall","F1-Score","ROC-AUC"]
        x=np.arange(len(keys)); w=.38
        fig,ax=plt.subplots(figsize=(6,4))
        ax.bar(x-w/2,[clf[dt][k] for k in keys],w,label=dt)
        ax.bar(x+w/2,[clf[nb][k] for k in keys],w,label=nb)
        ax.axhline(base,color="gray",linestyle="--",linewidth=1,label=f"Majority baseline ({base:.2f})")
        ax.set_xticks(x); ax.set_xticklabels(keys,rotation=20); ax.set_ylim(0,1)
        ax.set_ylabel("Score"); ax.legend(fontsize=8)
        st.pyplot(fig)
    with c2:
        st.write("**ROC curves**")
        fig,ax=plt.subplots(figsize=(6,4))
        for n in names:
            fpr,tpr=R["roc"][n]
            ax.plot(fpr,tpr,label=f"{n} (AUC {clf[n]['ROC-AUC']:.3f})")
        ax.plot([0,1],[0,1],"k--",linewidth=1,label="Random guess")
        ax.set_xlabel("False Positive Rate"); ax.set_ylabel("True Positive Rate"); ax.legend(fontsize=8)
        st.pyplot(fig)

    st.write("**Confusion matrices (test set)**")
    cc1,cc2=st.columns(2)
    for col,n in zip([cc1,cc2],names):
        col.write(n)
        col.dataframe(pd.DataFrame(R["cms"][n],
            index=["Actual Not Win","Actual Win"],
            columns=["Predicted Not Win","Predicted Win"]))

    st.markdown("### 3. Regression module (goals prediction)")
    r1,r2,r3,r4=st.columns(4)
    r1.metric("R² (test)",f"{reg['R2']:.3f}")
    r2.metric("R² (5-fold CV)",f"{reg['CV_R2']:.3f}")
    r3.metric("MAE",f"{reg['MAE']:.2f} goals")
    r4.metric("RMSE",f"{reg['RMSE']:.2f} goals")
    st.write(f"The model explains about **{reg['R2']*100:.0f}%** of the variation in goals scored. "
             f"On average the estimate is off by about **{reg['MAE']:.2f} goals** "
             f"(the average Team A scores {reg['mean_goals']:.2f}). Goals are rare, whole-number events, so even a good model "
             "cannot predict exact scores. Its real value is the *expected goals* it produces, which feed the Match Predictor and the "
             "Tournament Simulator.")

    st.markdown("### 4. Association Rules module")
    a1,a2,a3,a4=st.columns(4)
    a1.metric("Frequent itemsets",ar["itemsets"])
    a2.metric("Rules found",ar["rules"])
    a3.metric("Max lift",f"{ar['max_lift']:.2f}" if ar["rules"] else "-")
    a4.metric("Avg confidence",f"{ar['avg_conf']:.2f}" if ar["rules"] else "-")
    st.write(f"Strongest rule: `{ar['top_rule']}`")
    if ar["rules"] and ar["max_lift"]<1.2:
        st.write("A lift close to 1.0 means the items occur together only about as often as chance would predict, so these rules "
                 "describe the data rather than reveal strong patterns. The rules also describe attributes only and cannot predict a new match on their own.")
    else:
        st.write("These rules describe which match attributes occur together (for example, favourites and winning). "
                 "They explain patterns in past matches but do not predict a new match on their own.")

    st.markdown("### 5. Clustering module (K-Means, k=3)")
    k1,k2,k3=st.columns(3)
    k1.metric("Silhouette score",f"{km['silhouette']:.3f}")
    k2.metric("Davies-Bouldin index",f"{km['davies_bouldin']:.3f}")
    k3.metric("Inertia",f"{km['inertia']:.0f}")
    show_df(pd.DataFrame({"Cluster":list(range(km["k"])),"Matches":km["sizes"],
                          "Team A Win Rate":[f"{v*100:.1f}%" for v in km["win_rate"]]}),hide_index=True)
    spread=(max(km["win_rate"])-min(km["win_rate"]))*100
    st.write("Silhouette closer to 1 and Davies-Bouldin closer to 0 mean better-separated clusters. "
             f"Here the silhouette score of {km['silhouette']:.3f} "+
             ("shows only weak separation, so the groups overlap." if km["silhouette"]<.4 else "shows reasonable separation between the groups."))
    if spread>=10:
        st.write(f"The Team A win rate varies by **{spread:.1f} percentage points** across the clusters, which shows that team strength "
                 "and form relate to winning. However, a cluster only gives a group-level tendency, not a Win / Not Win answer for each "
                 "individual match. Clustering is best used for segmenting matches into types and as supporting insight, not as the predictor.")
    else:
        st.write(f"The win rate varies by only **{spread:.1f} percentage points** across the clusters, so grouping matches by these "
                 "features does not separate wins from non-wins. Clustering is best used for segmentation, not prediction.")

    st.markdown("### 6. Final verdict: which one suits our prediction system?")
    st.write("The goal of the system is to **predict whether a team will win**. Only the two classifiers are built for that, "
             "so they are scored on four metrics that matter for it (accuracy, F1-score, ROC-AUC and cross-validated accuracy). "
             "Training time is shown in the table above but not scored, since both models train in milliseconds.")
    score={n:np.mean([clf[n]["Accuracy"],clf[n]["F1-Score"],clf[n]["ROC-AUC"],clf[n]["CV Accuracy (5-fold)"]]) for n in names}
    best=max(score,key=score.get); other=[n for n in names if n!=best][0]
    margin=score[best]-score[other]
    show_df(pd.DataFrame({"Model":names,
        "Overall Score":[f"{score[n]:.4f}" for n in names],
        f"Metrics Won (of {n_scored})":[wins[n] for n in names]}),hide_index=True)
    st.success(f"✅ Best fit for the World Cup prediction system: **{best}**")

    if margin<0.01:
        st.write(f"The two classifiers are very close (overall score gap {margin:.4f}), so the choice depends on what matters most:")
    else:
        st.write(f"**{best}** leads on the overall score by {margin:.4f}.")
    reasons=[]
    if clf[best]["ROC-AUC"]>clf[other]["ROC-AUC"]:
        reasons.append(f"**{best}** ranks matches by win likelihood better (ROC-AUC {clf[best]['ROC-AUC']:.3f} vs {clf[other]['ROC-AUC']:.3f}).")
    if clf[best]["Accuracy"]>clf[other]["Accuracy"]:
        reasons.append(f"**{best}** has the higher test accuracy ({clf[best]['Accuracy']*100:.2f}% vs {clf[other]['Accuracy']*100:.2f}%).")
    if clf[best]["CV Std Dev"]<clf[other]["CV Std Dev"]:
        reasons.append(f"**{best}** is steadier across cross-validation folds (std dev {clf[best]['CV Std Dev']:.4f} vs {clf[other]['CV Std Dev']:.4f}).")
    if clf[other]["Recall"]>clf[best]["Recall"]:
        reasons.append(f"**{other}** catches more of the matches that Team A really wins (recall {clf[other]['Recall']:.3f} vs {clf[best]['Recall']:.3f}), "
                       "which matters if missing a win is costly.")
    if clf[other]["F1-Score"]>clf[best]["F1-Score"]:
        reasons.append(f"**{other}** has the higher F1-score ({clf[other]['F1-Score']:.3f} vs {clf[best]['F1-Score']:.3f}).")
    for r in reasons: st.markdown("- "+r)
    if margin<0.01:
        st.write(f"**Recommendation:** use **{best}** as the main model because it wins more of the metrics overall. "
                 f"Choose **{other}** instead only if catching as many wins as possible (recall) matters more than overall accuracy.")

    st.markdown("**How the other modules fit into the final system**")
    st.markdown(f"- **{best}** is the main engine for predicting Win / Not Win.\n"
                "- **Linear Regression** supports it by estimating expected goals for each side, which powers the Match Predictor scoreline "
                "and the Tournament Simulator.\n"
                "- **Clustering** supports it by grouping matches into types (mismatches, balanced games, high-scoring games).\n"
                "- **Association Rules** supports it by describing which attributes (favourite status, stage, confederation) go with each result.")

    best_acc=clf[best]["Accuracy"]
    if best_acc-base<0.05:
        st.warning(f"Honest note: the best accuracy ({best_acc*100:.2f}%) is only {(best_acc-base)*100:.2f} points above the "
                   f"{base*100:.2f}% majority baseline. Football results contain a lot of luck (draws and upsets), and this dataset is "
                   "generated with that randomness built in, so no technique can predict match results very accurately. "
                   "Real bookmakers' models also top out far below 100%.")

elif menu=="Match Predictor":
    st.subheader("Match Predictor: Team A vs Team B")
    data=preprocess(df)
    prof=team_profiles(data); teams=list(prof.index)
    dt,nb,lr=train_final_models(data)
    c1,c2,c3=st.columns(3)
    team_a=c1.selectbox("Team A",teams,index=teams.index("Brazil"))
    team_b=c2.selectbox("Team B",[t for t in teams if t!=team_a],index=0)
    venue=c3.selectbox("Venue",["Neutral","Team A is host","Team B is host"])
    home={"Neutral":0,"Team A is host":1,"Team B is host":-1}[venue]

    xrow=pd.DataFrame([pair_features(prof,team_a,team_b,home)],columns=CLS_FEATURES)
    p_dt=dt.predict_proba(xrow)[0,1]; p_nb=nb.predict_proba(xrow)[0,1]
    la,lb=expected_goals(lr,prof,team_a,team_b,home)
    grid=poisson_grid(la,lb)
    p_win=float(np.tril(grid,-1).sum()); p_draw=float(np.trace(grid)); p_loss=float(np.triu(grid,1).sum())

    st.markdown(f"### {team_a}  vs  {team_b}")
    m1,m2,m3,m4=st.columns(4)
    m1.metric(f"{team_a} Elo",f"{prof.loc[team_a].Elo:.0f}")
    m2.metric(f"{team_b} Elo",f"{prof.loc[team_b].Elo:.0f}")
    m3.metric(f"{team_a} win (Decision Tree)",f"{p_dt*100:.1f}%")
    m4.metric(f"{team_a} win (Naive Bayes)",f"{p_nb*100:.1f}%")

    st.markdown("**Win / draw / loss probability** (from expected goals of the Linear Regression model)")
    fig,ax=plt.subplots(figsize=(7,1.6))
    ax.barh([0],[p_win*100],color="#2e7d32",label=f"{team_a} win {p_win*100:.1f}%")
    ax.barh([0],[p_draw*100],left=[p_win*100],color="#f9a825",label=f"Draw {p_draw*100:.1f}%")
    ax.barh([0],[p_loss*100],left=[(p_win+p_draw)*100],color="#c62828",label=f"{team_b} win {p_loss*100:.1f}%")
    ax.set_xlim(0,100); ax.set_yticks([]); ax.set_xlabel("Probability (%)")
    ax.legend(ncol=3,fontsize=8,loc="upper center",bbox_to_anchor=(.5,1.6),frameon=False)
    st.pyplot(fig)

    flat=[(i,j,grid[i,j]) for i in range(grid.shape[0]) for j in range(grid.shape[1])]
    flat.sort(key=lambda t:-t[2])
    top=pd.DataFrame([{"Scoreline":f"{team_a} {i} - {j} {team_b}","Probability":f"{p*100:.1f}%"} for i,j,p in flat[:5]])
    e1,e2=st.columns(2)
    e1.metric(f"Expected goals: {team_a}",f"{la:.2f}"); e2.metric(f"Expected goals: {team_b}",f"{lb:.2f}")
    st.write("**Most likely scorelines**")
    show_df(top,hide_index=True)
    st.caption("Team ratings are the average Elo, rank, form and squad value of each team across the dataset.")

elif menu=="Tournament Simulator":
    st.subheader("World Cup Tournament Simulator (Monte-Carlo)")
    st.write("Simulates a 32-team World Cup: 8 groups of 4 (top two advance), then Round of 16, Quarter-finals, Semi-finals and the Final. "
             "Goal rates for every pairing come from the Linear Regression module, and goals are drawn from a Poisson distribution. "
             "Groups are drawn at random in every simulation, so the result is an average over many possible draws.")
    s1,s2=st.columns(2)
    n_sims=s1.slider("Number of simulated tournaments",500,5000,2000,500)
    seed=int(s2.number_input("Random seed",value=42,step=1))
    if st.button("Run Simulation"):
        with st.spinner("Simulating tournaments..."):
            st.session_state["wc_sim"]=simulate_tournament(preprocess(df),n_sims,seed)
    if "wc_sim" in st.session_state:
        sim=st.session_state["wc_sim"]
        top=sim.index[0]
        st.success(f"🏆 Most likely champion: **{top}** ({sim.loc[top,'Champion']:.1f}% of simulations)")
        fig,ax=plt.subplots(figsize=(8,5))
        t10=sim.head(10).iloc[::-1]
        ax.barh(t10.index,t10["Champion"],color="#f9a825")
        ax.set_xlabel("Chance of winning the World Cup (%)")
        st.pyplot(fig)
        st.write("**Probability of reaching each stage (%)**")
        show_df(sim.round(1))
    else:
        st.info("Press **Run Simulation** to start.")

st.sidebar.markdown("---")
st.sidebar.caption("Python + Streamlit + Pandas + Scikit-learn + mlxtend")
